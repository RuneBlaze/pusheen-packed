<template>

<div>
  <pusheen-nav></pusheen-nav>

    <div class="container">
      <router-link to='/' style="color: gray">Back</router-link>
      <h1>{{card.name}}®</h1>

      <div class="row">
        <div class="col-md-4 ">
          <img v-bind:src="card.image" id="card_img">
          <router-link :to="{ name: 'apply', params: { id: id }}" role="button" class="btn btn-primary">Apply Now</router-link>
        </div>

        <div class="col-md-1"></div>

        <div class="col-md-7 ">
          <h5>Features</h5>


            <li v-for="feature in card.features">
              {{feature}}
            </li>

        </div>
      </div>

      <div class="table-responsive">
        <table class="table">
          <thead class="thead">
            <tr>
              <th scope="col-md-3">Intro APR</th>
              <th scope="col">Regular APR</th>
              <th scope="col">Rates and Fees</th>
              <th scope="col">Credits Recommended</th>
            </tr>
          </thead>

          <tbody>
            <tr>
              <td scope="row">
                {{ card.intro_apr.rate}}% Intro APR for {{card.intro_apr.months }} months
              </td>
              <td>{{Math.round(card.regular_apr.rate*10000) / 100}}%</td>
              <td>
                ${{card.rates_and_fees[0].fee}} {{card.rates_and_fees[0].name}} fee
                <span v-if="card.rates_and_fees[1]">
                  ;<br>
                  {{Math.round(card.rates_and_fees[1].rate*10000) / 100}} Intro APR on
                  balance transfers for {{card.rates_and_fees[1].duration_months}} months
                </span>
              </td>
              <td>
                {{ card.recommended_credit_scores[0].name}}/{{card.recommended_credit_scores[1].name}}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div id="bottom"></div>
  </div>

</template>

<script>
import {retrieveCards, applyCard, cards} from '../rv'
import Nav from '@/components/Nav'
export default {
  name: 'Card',

  data () {
    return {
      msg: 'Welcome to Your Vue.js App',
      creditScore: 0,
      card: cards[this.id],
    }
  },

  components: {
    'pusheen-nav': Nav
  },

  props: ['id'],

  methods: {
    apply () {
      applyCard(82457245, this.creditScore, (err, res) => {
        if (err) alert(err)
        else {
          alert(JSON.stringify(res))
        }
      })
    }
  }

}


</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/*****navbar set up ******/

/*main content*/
.thead {
  color:white;
  border-style: none;
  text-align: center;
  box-shadow: 5px;
}

thead{
  border:1px solid black;
}

th{
  color:white;
  background-color: #242942;
  border:1px solid black;
}

td {
  border: none;
  text-align: center;
  border:1px solid black;
}

button{
  margin-top: 20px;
  margin-bottom: 20px;
  background-color: #FF8800;
  border:0px;
  color:white;
  height: 50px;
  width: auto;
}

.thead-dark{
  background-color: #242942;
}

#card_img{
  border-radius: 10%;
  max-width: 100%;
  max-height: 250px;
}

#bottom{
  margin-top: 50px;
  height:70px;
  background-color: #242942;
}
</style>
